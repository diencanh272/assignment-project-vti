import "./App.css";
import AccountPage from "./pages/AccountPage";

function App() {
    return (
        <div>
            <AccountPage />
        </div>
    );
}

export default App;
